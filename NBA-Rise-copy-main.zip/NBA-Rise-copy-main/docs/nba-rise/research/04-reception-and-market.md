<!-- Research report compiled 2026-11-08. Source links inside; working-file paths refer to a temporary session folder that was not preserved (the official pack data is preserved in ../data/). -->

# NBA RISE: reception, market and competitor research (data as of 2026-11-08)

**How to read the labels**
- **[C] Confirmed:** read directly from a primary or official page (store, official site, SEC filing, publisher press release).
- **[R] Reported:** taken from a secondary outlet.
- **[E] Estimate:** for example, Google Play's unrounded install field.
- **[I] My inference.**

**Keep the two titles apart:**
- **NBA RISE: Basketball Strategy** is the global card game. GRAVITY Co. (Seoul) runs it. It launched in 8 regions on **2026-10-20** after a closed beta on 2026-07-21/22 to 07-29 and pre-registration from 2026-09-17. So it is only about 19 days old, and every review signal here is launch-period data.
- **NBA RISE (Japan)**, formerly NBA RISE TO STARDOM, was run by the subsidiary GRAVITY GAME ARISE (GGA). Its service ended 2026-08-31.

---

## 1. Key takeaways
1. **The global game's store ratings are high but thin and launch-skewed.**
   - Google Play shows 4.2–4.8 depending on region, on 1.12K ratings. The App Store shows 4.2–5.0 per region, on 6–63 ratings each.
   - The roughly 4.2 figure you have is the **Australia** headline. Korea, Thailand and New Zealand show 4.7, Indonesia and Malaysia 4.8, Philippines 4.6, Singapore 4.5.
2. **The Korean Google Play reviews look atypical.**
   - 498 written Korean-locale reviews: 497 are 4–5★, 1 is 1★, none are 2–3★.
   - 61% were posted in the first 3 days. Average length is 32 characters, and many read like promotional copy.
   - The developer's replies ask unhappy reviewers to "change your rating to 5 stars."
   - [I] Treat the Korean rating with caution. I cannot verify the cause.
3. **The real complaint themes, from English, Indonesian and Thai Google Play reviews plus App Store reviews:**
   - Access: stuck on the loading, title or black screen. Many cases are the IP region lock.
   - Gacha rates and pay-to-win.
   - Stamina/fatigue balance and long simulated matches.
   - "Not compatible" errors after update 1.1.1.
   - Payments not delivered (Thailand).
   - Mode bugs: Tower Race, Club, Match Prediction, code redemption.
   - Thin content and repetitive play.
   - Rosters still 2025-26 although the 2026-27 season has started.
   - AI-art accusations.
   - Some users want direct control; one Thai reviewer compares it to the just-closed NBA Live Mobile.
4. **What players praise:** low-effort play (auto mode, skip), real licensed players and legends, card collecting, real-time substitution and tactics, generous free packs, and "reasonable" offer prices.
5. **Revenue and chart position are modest.** [C] On 2026-11-08 the game is outside the iOS **overall Games** top-100 (grossing and free) in all 8 regions. In the iOS **Sports games** subgenre its top-grossing ranks are: Indonesia #12, Philippines #18, Singapore #20, Thailand #26, Malaysia #35, Korea #38, New Zealand #38, Australia #42.
6. **Japan:** written reviews averaged about 1.8★ in 2021–22, then about 4.5★ after the Feb-2025 relaunch. The official shutdown reason is the "current development and operating structure." After 2026-01-01 the official site posted only maintenance and bug notices, and players complained of abandonment from April 2026.

---

## 2. Store ratings snapshot (fetched 2026-11-08)

### 2a. Global game: Google Play `com.gravity.nbarisegv.aos` [C]
- **Headline rating by region:** PH 4.6 · KR 4.7 · **AU 4.2** (phone tab 4.3) · ID 4.8 · TH 4.7 · MY 4.8 · SG 4.5 · NZ 4.7. US and JP pages show no rating (not launched there).
- **Total ratings:** 1,120 (global pool). Written reviews visible: about 570.
- **Star histogram (PH view):** 1★ 67 · 2★ 19 · 3★ 28 · 4★ 95 · 5★ 909. Google shows region-weighted variants, for example AU [186, 0, 0, 186, 746] and KR [8, 0, 8, 274, 824].
- **Installs:** badge says "100K+". The unrounded `realInstalls` field reads **298,491** [E]. [I] This likely includes beta installs, since the beta also ran on Google Play.
- Listed as released Oct 19, 2026 (UTC), version 1.1.1, updated Oct 28.
- Age rating varies: 16+ in most regions, 15+ in KR, Mature in AU.

### 2b. Global game: App Store id6762187862, listed as "NBA RISE: Basketball Cards" (KR: "NBA RISE: 농구 카드 전략") [C]

| Region | Rating (count) | Chart badge on product page |
|---|---|---|
| PH | 4.80 (41) | No. 11 Sports |
| KR | 4.81 (48) | #31 Card |
| TH | 4.89 (63) | No. 11 Sports |
| ID | 5.0 (28) | No. 36 |
| MY | 5.0 (13) | No. 48 |
| SG | 4.2 (10) | No. 26 |
| AU | 4.27 (22) | No. 59 Sports |
| NZ | 4.33 (6) | No. 147 |

- Released 2026-10-20; version 1.1.1 on about Nov 5.
- Languages: KO, EN, ID, ZH-CN, ZH-TW, TH, Filipino.
- The age label lists "Random boxes" and "Ads."

### 2c. Japan predecessor [C]
- **App Store id1574474570:** 3.4★ from 1,858 ratings, cumulative 2021–2026. Still listed; last version 2.0.14 on 2026-08-31.
- **Google Play `com.gravityga.nbarisetostardom`:** 4.34★ from 540 ratings. Histogram 26/21/59/64/366. Badge "50K+", unrounded installs **52,743** [E]. Last updated 2026-08-14.
- **Written-review averages by era** [C, my tally of feed data]:
  - App Store (384 most recent written reviews): 2021 1.81 (n=264) · 2022 1.87 (n=54) · 2023–24 about 1.8 (n=6) · 2025 4.5 (n=58) · 2026 4.5 (n=2).
  - Google Play (196 written reviews): 2021 2.1 (n=108) · 2022 2.55 (n=38) · 2025 3.96 (n=47) · 2026 2.0 (n=2).
  - [I] About 50 uniformly positive, similarly styled reviews cluster between 2025-07-24 and 2025-10-01. That window follows the Yuki Kawamura ambassador announcement (2025-07-10). The cause is unverified.
- **No third-party aggregate found:** app-liv.jp has only a 2021 editorial with no score. No game-i.daa.jp page exists for the title; its search returns nothing. [I] That suggests it never charted meaningfully in Japanese top-grossing, but this is a weak signal.

---

## 3. Global game: review themes with representative quotes
Theme counts come from the non-Korean set: Google Play EN 30, ID 23, TH 18, plus App Store PH/AU/SG/TH/ID/KR about 26.

**Praise**
- Low time commitment, fair prices: "This game is fun, if you don't really have much time to play, you can use the skip button and also the prices of the offers are reasonable. It's easy to get good players." (GP 5★, 2026-10-28, 6 helpful)
- Collecting and strategy: "Best for people who enjoy collecting players, improving line ups and strategy on offensive and defensive play… Also has a lot of room for improvement." (iOS PH 5★)
- Indonesian genre comparison: "Very fun. Like a football game combining FC Mobile & Football Manager." (GP ID 5★, 10-24)
- Korean, balanced: "Fun building a dream team… but repetitive match flow, player gacha and spending pressure are drawbacks." (GP KR 5★, 10-20)
- Korean reviewers frequently praise auto-play, the 10 free cards per day from login, picking a starter Epic, and the tutorial.

**Gacha and pay-to-win (about 7 mentions)**
- "P2W game, period, gacha rates the worst, and not f2p friendly" (GP 1★, 10-30)
- "50 pulls no good card" (GP 1★, 10-30)
- "Good mechanics but rates are low" (GP 5★, 10-21, 17 helpful)
- "PAY TO WIN" (GP ID 1★)
- Thai: "drop rate is brutal" (5★)
- Thai, long 1★ (10-24, 8 helpful), translated: "A dumb card game stuffed with systems… higher power doesn't mean you win… stamina and form systems are annoying… pack rate: opened 200, got 2 [Epics], 1 of them the guarantee… Silver is scarce but used heavily… no stages to farm… repetitive animations… bugs moving players… an auction that uses diamond currency you can't obtain."
- Korean 1★, translated: "badly optimized ad-game with AI… lots of ads, monetization, gacha [rate manipulation], crashes and lag, AI illustrations and modeling."

**Access, stability and compatibility (about 12 mentions; the largest negative cluster)**
- "what a waste of time. have uninstalled and reinstalled this game so many times and still stuck on the loading screen." (GP 1★, 10-22, 14 helpful). The developer replied that the game is IP-locked to the 8 regions.
- Similar reports: stuck at the title screen or homescreen, "won't open," a black screen after the NBA logos (iOS AU, 11-04).
- After update 1.1.1: "not compatible in my device" (GP EN 11-05, ID 11-05, TH 11-06), and a login/redownload loop (ID 1★).
- Thailand: "Topped up, money deducted but item not received" (1★), plus a second similar refund request.
- Mode bugs: Tower Race won't open, Club mode won't open, Match Prediction rewards gone, codes "already used."

**Match pacing, stamina and control**
- "The games take way too long with animation that is totally unnecessary… Playing a weird simulated full match, where you have to manually subs tired players is not fun." (iOS AU 1★, 10-30). The developer pointed to Full Auto Mode, Auto Player Substitution and SKIP.
- "can't win for 4 games in rookie… stamina drain much faster than opponents" (GP 1★)
- Thai 2★, translated: "Should let you control players like NBA Live Mobile… cards tire too easily… NBA Live Mobile, which just shut down, had no fatigue limit."
- Indonesian 1★, translated: "I don't like that the play isn't shown directly, so I can't tell which position is which."
- "Totally no idea what is game is about… overwhelmed by the stuff to click and collect." (iOS SG 1★)

**Content depth, QoL and roster freshness**
- Korean 4★ (iOS, 11-01; the reviewer says they spend a little), translated: "Play ends up being just a few league games, finished with a few monotonous clicks, so it gets boring fast." The same reviewer asks for bulk pack-opening and bulk exchange.
- "Uses AI as art and not updated on the current NBA rosters." (GP 1★)
- Korean iOS 4★: "Still seems to be the 25-26 roster; when is the 26-27 update?" The official launch release confirms 2025-26 rosters.
- Feature requests: legends (Yao Ming, Kareem), home/away labels, editable jersey numbers, once-per-quarter tactics in PvP.

**Translation and localization:** I found no complaints about translation quality. Data unavailable beyond that.

**Developer response behavior [C]:** The developer replies to nearly every review, in English, Korean and Thai. It repeatedly asks for rating upgrades, for example: "we'd really appreciate it if you'd consider updating your rating to 5 stars." In Korean: "플레이 경험이 개선된다면 별점도 5점으로 변경해 주시면 감사하겠습니다" ("please change it to 5 stars if your experience improves").

---

## 4. Japan predecessor: reception arc

**2021–22 (RISE TO STARDOM): mostly negative**
- Gacha and spending:
  - "ガチャの確率が闇。最高レア0.2%。上から二番目のレアリティで1.3%" → "Gacha odds are dark: top rarity 0.2%, second 1.3%." (iOS 2★, 2021-11)
  - "課金で補うのであれば廃課金確定（月20万以上）" → "Compensating with money means certain whale status (¥200,000+/month)." (iOS 1★)
  - "戦力差があると厳しい(課金した者勝ち)" → "With a power gap it's tough — whoever pays wins." (iOS 4★)
- Launch stability: iOS black screen on launch and crashes ("真っ黒！"), lost paid data, score set to 0 on network error. Denfaminicogamer (2021-11-26) also reported deleted accounts and a playoffs network error at launch.
- Quality: "クオリティもブラウザゲームが少し進化した程度" → "quality is like a slightly evolved browser game." The same reviewer adds: "日本ではNBAが浸透していない" → "the NBA isn't widespread in Japan." (GP 1★, 2022-05, 24 helpful)
- Pacing: unskippable 3D sequences and long seasons or playoffs played manually.

**2023–24: stagnation.** iOS reviews ask "サービス終了してんのか？" ("Has it shut down?") with no updates or roster changes. App versions jump from 1.5.6 (2023-02-09) to 2.0.0 (2025-02-20). Long-term maintenance began 2024-09-30.

**2025 relaunch: auto mode and skip were well received**
- "アップデート以前は試合のテンポが悪く、オート進行が無かった…かなり改善されている" → "Before the update matches were slow with no auto-progress… greatly improved." (GP 5★)
- Dissent: "オート機能追加…それ以外は以前のものと大差なく" → "Only auto mode is new; otherwise not much different." (GP 1★, 2025-03-30)
- Event spending: "イベントでハイスコア出すには、イベントのガチャから出るブーストキャラがいないといけない…無課金微課金へのサービスとかチャンスもある程度ないとサ終するね！" → "To score high in events you need boost players from the event gacha… without some chances for free or light spenders, it'll shut down!" (iOS 4★, 2025-09-19)
- Small audience: "日本だとあんまりNBA知ってる人が少なくて…プレイ人口も少ない" → "Few people in Japan know the NBA, so the player base is small." (GP 3★)
- Stale data: "データが古すぎる…レイカーズのヘッドコーチがレディックじゃない" → "Data too old; the Lakers HC isn't Redick." (GP 2★)

**2026: wind-down**
- "1/29を最後に運営からのアナウンスはありません…現在はイベントの更新も無く放置状態。また裏切られた気分。" → "No announcements since Jan 29… no event updates, abandoned. I feel betrayed again." (GP 1★, 2026-04-13)
- "イベントもキャラの追加も無くなった…誰もプレイしてないんちゃう" → "No more events or new players… is anyone even playing?" (GP 3★, 2026-06-03)

---

## 5. Why the Japan service ended
- **Official notice "【重要】NBA RISEサービス終了のお知らせ" (nbarise.com/reinsde, 2026-07-30)** [C]. Stated reason, verbatim: 「現在の開発・運営体制を考慮したうえでたび重なる協議を行いました結果、今後お客様にご満足いただけるサービスの提供が困難であるとの結論に至りました」 → "After repeated discussions taking the current development and operating structure into account, we concluded it would be difficult to keep providing a service that satisfies customers." No other reason is given.
- **Timeline** [C]:
  - Paid gold sales ended 2026-07-30 15:00.
  - Service ended 2026-08-31 17:00 JST.
  - Refunds of unused paid gold under Payment Services Act Art. 20(1) ran 2026-08-31 17:00 to 2026-11-16 12:00, valued at **¥2 per paid gold**, paid out via CASH POST between mid-Dec 2026 and about Jan 2027 (nbarise.com/ypgreqa).
  - A notice also ran in the official gazette (官報) on 8/31 (gamebiz).
- **Dengeki Online (2026-08):** launched 2021-11-18 (store date); long-term maintenance from 2024-09-30; relaunched 2025-02-20; total run about 4 years 9 months. The excerpt states no reason.
- **Supporting signals** [C, interpretation I]:
  - The last new scout announcement on the official site was "RISING SCOUT" on 2026-01-01. After that, only maintenance and bug posts appear (Jan 22, Jan 27/29, Apr 30, Jul 2, Jul 9).
  - The last iOS content update was 2.0.12 (2025-11-27). 2.0.13 (2026-04-30) only changed the icon.
  - The audience was small: about 52.7K lifetime Android installs [E] and 1,858 iOS ratings over 5 years.
  - GGA, which runs several titles, lost money: revenue ₩5,574M with a ₩(6,237)M loss in 2024, and ₩14,995M with a ₩(2,513)M loss in 2025 (Gravity 20-F for FY2025). NBA RISE's share is not disclosed.
  - The same 20-F says the NBA/NBPA license from May 2020 "was extended [in 2025] and additional license fees were committed."
  - [I] The Japanese shutdown came about 7 weeks before the global game launched, but no official statement links the two. vegcale.com (as of Aug 8, 2026) found no successor announcement.
  - Gravity's Q2-2026 6-K does not mention NBA RISE. I did not find Q3-2026 results as of Nov 8.

---

## 6. Downloads, revenue and rankings

| Metric | Value | Status / source / date |
|---|---|---|
| Global GP installs | 100K+ badge; 298,491 unrounded | [C] badge / [E] field, 2026-11-08 |
| Global GP ratings | 1,120 | [C] |
| Global iOS ratings | 231 across 8 regions (41+48+22+10+63+28+13+6) | [C] |
| iOS Sports top-grossing, 11-08 | ID #12, PH #18, SG #20, TH #26, MY #35, KR #38, NZ #38, AU #42 | [C] Apple RSS genre 7016 |
| iOS Sports top-free, 11-08 | PH #11, TH #11, SG #39, KR #49, ID #56, AU #59, MY #84, NZ not in top 100 | [C] |
| iOS overall Games top-100 (grossing and free) | Not present in any of the 8 regions | [C] |
| Same-day Sports grossing peers | KR: NBA Dunk City #10, NBA 2K Mobile #20; PH: Dunk City Dynasty #6, NBA 2K Mobile #11, NBA Collect #13 | [C] |
| Global pre-registration count | Not published. A "global pre-registration goal event" ran from 2026-09-17, but its thresholds are not in the site text | data unavailable |
| Global revenue estimate | Unavailable. AppMagic, Sensor Tower and data.ai pages are login or JS-gated; AppBrain returned 403 | data unavailable |
| Japan pre-registration (2021) | 50,000+ | [R] GGA press release 2021-11-01 (search snippet) |
| Japan GP installs, lifetime | 50K+ badge; 52,743 unrounded | [C] / [E] |
| Korea Google Play top-grossing history | Not publicly accessible | data unavailable |

---

## 7. Monetization perception

**Gacha disclosure** [C] (probability.gnjoy.com, Korea's legally required disclosure; "SCOUT & PLAYER PACK" merged 2026-10-22)
- Standard and paid season packs (25-26 Season, The Core): **EPIC 0.5%**, UR 7.5%, Rare 15%, UC 27%, Common 50%.
- Themed packs (EDITION, LOCKDOWN, HALLOWEEN, FLAME): **LEGEND 0.1%**, EPIC 0.5%, the rest the same.
- Pity: **100 cards bought guarantees an EPIC** on season and themed packs; **200 cards guarantees a LEGEND** on EDITION. A wishlist steers which EPIC you get.
- The free Starter pack has EPIC at 0.1%.
- Diamond Box: 10 packs, each EPIC 0.5% or diamonds (15K at 56.5%, 30K at 26%, 60K at 12%, 100K at 5%).
- [I] The Thai "opened 200, got 2" report is consistent with these rates plus pity.

**Price ranges (Google Play, per item)** [C]: KR ₩1,200–55,000 · AU A$1.39–57.90 · SG S$1.28–49.00 · TH ฿25–1,270 · ID Rp17,000–610,000 · PH ₱54–2,150 · US-locale listing $0.79–36.99.

**In-app purchase lists on App Store product pages** [C]

| Region | Items shown |
|---|---|
| PH | Diamond Box, Beginner, Training, Currency Pack I, Light Core Support, Rookie, all ₱55; MVP New Arrival Pack ₱390; Regular Core Support ₱175; Regular New Arrival ₱175 |
| KR | 다이아 박스 / 초보자 / 훈련 / 재화 I / 라이트 코어 서포트 / 루키, all ₩1,200; 골드 100,000 ₩19,000; 명예의 전당 패키지 (Hall of Fame) ₩22,000; 레귤러 코어 서포트 ₩4,400 |
| AU | Six items at A$1.39; 100,000 Gold A$20.49; Regular Core Support A$4.69; All-Star Package A$7.69; **Elite Pass A$15.49**; Veteran Package A$2.19 |
| SG | Quadruple-Double S$4.99; MVP New Arrival S$8.78; 100,000 Gold S$18.00; All-Star S$6.99; others S$1.28–3.99 |
| MY | 100,000 Gold RM57.90; Core Value Package RM29.90; Regular New Arrival RM12.90; others RM4.00 |
| ID | 100,000 Gold Rp215K; MVP Core Support and MVP New Arrival Rp111K; Regular New Arrival Rp49K; others Rp17K |
| NZ | 100,000 Gold NZ$21.49; MVP Core Support NZ$11.49; Regular Core Support NZ$5.09; Double-Double NZ$3.79; others NZ$1.49 |
| TH | Mostly ฿25 items |

- [I] The lists are dominated by about US$1 starter items, which fits early-launch low-ticket buying.
- **Typical spend per player: no data available.**

**Japan predecessor**
- App Store IAP [C]: 230 Gold ¥500 · 510 Gold ¥1,300 · 2,400 Gold ¥3,600 / ¥4,500 · 3,200 Gold ¥7,000 · 3,600 Gold ¥4,800 · 5,000 Gold ¥8,000 · 7,500 Gold ¥15,000. Google Play range ¥120–12,000. Refund value ¥2 per gold.
- Users in 2021–22 reported top-rarity odds of 0.2–1.5% [R, user-reported].

**Overall perception:** opinion is split.
- Positive: "offers are reasonable," "plenty of free rewards" (KR, JP), "easy to get good players."
- Negative: "P2W," "rates are low," "no good card after 50 pulls," Silver scarcity, an unobtainable auction currency (TH), and Japan's event-gacha dependence.

---

## 8. Community footprint (2026-11-08)
- **Discord (discord.gg/Sz4Za6ZrMy, "NBA Rise")** [C]: **2,740 members, 98 online.** Joining by 11/10 earned 500 Gold + 10,000 Silver, which inflates the count.
- **YouTube @PLAYNBARISE** [C]: **90 subscribers**, 29 videos. Trailer views: CBT trailer 2.3M, animation teaser 1.9M, Launch trailer 424K, "The Dream" EP1 EN 579K / KR 147K, most others 36K–162K. [I] The view-to-subscriber gap suggests paid ad views.
- **Instagram @playnbarise** [C]: 1,770 followers, 23 posts.
- **Facebook** (profile id 61590508838426) exists; follower count could not be retrieved.
- **X/Twitter:** no global account found. The official site links Discord, Facebook, Instagram and YouTube only. Japan's @NBA_RISE had **7,001 followers** and 1,549 posts, joined 2021-02-08 [C via fxtwitter API].
- **Reddit:** no threads found. Reddit's API returned 403 and web searches found nothing.
- **DCInside (Korea):** the only hit is a repost of GameMeca's beta news in the basketball gallery (2026-07-23). No organic discussion was found.
- **YouTube creators and tier lists:** none found. MuMuPlayer has a Thai beginner guide (emulator marketing).

---

## 9. Press coverage
- **English:** Inven Global covered the beta (2026-07-21) and launch (2026-10-19); GameMeca EN (2026-10-20; the "August 20" in its text is a translation error); UnGeek PH beta piece (2026-07-22, descriptive); GamingOnPhone on pre-registration (2026-09-16) and beta. **No critical English review found.**
- **Korean:**
  - iNews24 "[겜별사] 직접 컨트롤하지 않아도 재밌다" (2026-10-31): positive. It praises tactics and substitutions, condition-based stats, graphics ("그래픽 완성도도 뛰어났다" → "graphics quality was excellent") and tier rerolls. Verdict: "스포츠 매니지먼트 게임을 선호하는 이용자라면 충분히 즐길 만하다" → "users who like sports management games can fully enjoy it." No monetization critique.
  - Business Watch (2026-07-22) and GameMeca: news only. ThisIsGame was a press release and returned 403. No Inven KR review found.
- **Japanese (2021 predecessor):**
  - gamebiz 337867 "【レビュー】…": positive feature, no criticism or pricing.
  - Denfaminicogamer: **explicitly a sponsored tie-up** ("タイアップ企画"), 2021-11-25.
  - Game Watch 【特別企画】 hands-on (2021-11-25): positive; only negative is hours-long skill-training waits.
  - app-liv editorial (2021-12-01).
  - No Famitsu or 4Gamer critical review found; shutdown coverage from gamebiz and Dengeki only.

---

## 10. Competitive landscape (status as of 2026-11-08)

| Title (publisher) | Play style | Launch | Status | Store signals [C/E] | How NBA RISE differs |
|---|---|---|---|---|---|
| NBA 2K Mobile (2K / Cat Daddy) | Card collecting plus real-time action games | 2018–19 | Live, updated Oct 2026 | GP 4.73, 10M+ (≈27.9M); iOS US 4.76 / 1.69M ratings | RISE has no direct control; you coach a simulation |
| NBA 2K26 MyTEAM Mobile (2K) | Console-style MyTEAM, action | Nov 2025 | Live | GP 1M+ (≈1.19M) | Same |
| NBA 2K27 Arcade Edition (2K, Apple Arcade) | Premium action, no IAP | 2026-11-05 | New | iOS US 4.69 (892) | Free-to-play with gacha vs subscription |
| NBA Infinite (Level Infinite / Proxima Beta, Tencent) | Real-time PvP action | Feb 2024 | Listed, but **no update since 2026-03-25/26**; no shutdown notice found | GP 3.76, 10M+ (≈11.6M) | Same |
| Dunk City Dynasty / NBA Dunk City (NetEase) | 3v3 street MOBA-style action | Global May 2025; KR 2026-08-06; JP 2026 | Live, strong | GP 4.75, 1M+ (≈4.0M); KR iOS Sports grossing #10, PH #6 | Same |
| NBA Basketball World 2026 (HK Qushang / "QS Games") | Team-president or manager card game with "dynamic player power" | iOS 2026-05-21 (PH, KR, JP, AU) | Live | GP 100K+ (≈329K); iOS 4.7–4.9; AU Sports grossing #86 | **Closest genre rival in RISE's own regions** |
| NBA Collect by Topps | Digital trading cards and contests | Nov 2025 | Live | GP 100K+ (≈167K); PH #13, SG #12, NZ #14 Sports grossing | Collection only, no match simulation |
| NBA LIVE Mobile (EA) | Action plus team building | 2016 | **Reported shut down 2026-10-27** [R, GamingHQ 2026-10-18; no EA release found]; not found in store searches. A separate "EA SPORTS NBA Live Mobile Beta" listing remains on GP (100K+) | — | A Thai reviewer cites it as an audience that wants direct control |
| NBA Clash (Nifty Games) | Real-time action | 2022 | Delisted June 2023 when the studio closed [R, PocketGamer.biz] | — | — |
| NBA SuperCard (2K) | Card battler | 2020–21 | Sunset 2023-09-13 [C, 2K page] | — | Closest past card-battle analogue |
| NBA All-World (Niantic) | Location-based AR | 2023 | Shut down 2023 [R] | — | — |
| NBA NOW / NOW 22 / NOW 24 (Com2uS) | Team management and simulation | 2020–21 | **Not on the App Store (US/PH/KR/JP) or in Google Play search**; last iOS update 2024-03-12 [R]; no shutdown notice found | — | Prior licensed management sim, now gone |
| NBA Ball Stars (Netmarble / Kung Fu Factory) | Puzzle | Apr 2021 | Not found in stores; shutdown date unverified | — | — |
| "NBA Champions" (Mighty Bear?) | — | — | **No evidence such a game exists** | — | — |
| Hoop Land (Koality) | Unlicensed retro sim / arcade | 2023 | Live | GP 1M+ (≈3.1M), single US$4.99 IAP | Paid depth, no gacha |
| Basketball GM-type (Taproom "Basketball Fantasy Manager NBA", Ultimate Pro Basketball GM, Hoop Dynasty) | GM sims | various | Live | Taproom GP 5M+ (≈6.8M), 3.68★ | Text and management, unlicensed |
| SLAM DUNK (DeNA China / Tadpole) | Anime action | 2020–21 | Live | KR iOS Sports grossing #31 | Competes for basketball spend in Asia |
| Gravity sports sibling: JLPGA Heroine Collection (GGA, Japan) | Golf card collecting | 2025-03-25 | Live, updated 2026-10-29 | iOS JP 3.1★ (318) | Same licensed-sports card model |

**Japanese NBA mobile history:** Marvelous's NBA CLUTCH TIME ended service earlier (gamebiz 155885). A 2021 reviewer also mentions a recently closed "NBAドリームチーム," which I did not verify.

[I] **Positioning:** NBA RISE is one of very few live NBA-licensed games built on strategy and simulation with no reflex control. Its most direct live rival in its regions is NBA Basketball World 2026. The action games (2K, Dunk City, Infinite) dominate installs and grossing. Several earlier licensed management or card games (NBA NOW, SuperCard, Clash) have disappeared.

---

## 11. Not found or unavailable
- Sensor Tower, AppMagic and data.ai downloads and revenue: gated.
- Korea Google Play top-grossing history.
- Global pre-registration totals.
- Facebook follower count.
- Reddit threads.
- Typical spend per player.
- Pre-launch Japanese reviews from Famitsu or 4Gamer.
- Q3-2026 Gravity results.
- An official EA notice for the NBA Live Mobile shutdown.
- The shutdown date for NBA NOW.

Raw data saved in the scratchpad:
- `(session scratchpad, not preserved)/gp/reviews.json` (global Google Play reviews)
- `(session scratchpad, not preserved)/gp/jp_reviews.json` (Japan Google Play reviews)
- `(session scratchpad, not preserved)/as/rss_jp.json` and `.../as/rss_*.json` (App Store reviews)
- `(session scratchpad, not preserved)/charts/` (iOS chart snapshots)
- `(session scratchpad, not preserved)/prob/` (gacha disclosure pages)

---

## 12. Sources

**Stores and official pages**
- https://play.google.com/store/apps/details?id=com.gravity.nbarisegv.aos (gl=PH/KR/AU/ID/TH/MY/SG/NZ)
- https://apps.apple.com/ph/app/id6762187862 (also /kr, /au, /th, /sg, /id, /my, /nz); iTunes lookup and search APIs; https://itunes.apple.com/{cc}/rss/customerreviews/id=6762187862/json
- https://apps.apple.com/jp/app/id1574474570 ; https://itunes.apple.com/jp/rss/customerreviews/id=1574474570/json ; https://play.google.com/store/apps/details?id=com.gravityga.nbarisetostardom
- Apple charts: https://itunes.apple.com/{cc}/rss/topgrossingapplications/limit=100/genre=7016/json (and topfree; genre 6014)
- https://nbarise.gnjoy.com (official global site) ; https://probability.gnjoy.com/NBA/NBARISE/NBARISE/NBA-NOTIFY ; https://prd-clutch-api.gnjoy.com/ext/news/offerrate?offerGroupId=10020 (also 10050, 10090, 20240, 40010–40120, 30010)
- https://discord.gg/Sz4Za6ZrMy ; https://www.youtube.com/@PLAYNBARISE ; https://www.instagram.com/playnbarise ; https://www.facebook.com/profile.php?id=61590508838426 ; https://x.com/NBA_RISE
- https://nbarise.com/ ; https://nbarise.com/reinsde/ ; https://nbarise.com/ypgreqa/ ; https://nbarise.com/ct/news/

**Filings**
- https://www.sec.gov/Archives/edgar/data/1313310/000162828026026985/grvy-20251231.htm (FY2025 20-F)
- https://www.sec.gov/Archives/edgar/data/0001313310/000162828026054549/a6-k_gravityxsecondquarter.htm (Q2-2026 6-K)

**Press**
- https://www.invenglobal.com/articles/27412/gravity-officially-launches-nba-rise-across-8-regions
- https://www.invenglobal.com/articles/24039/gravity-launches-cbt-for-nba-rise-an-officially-licensed-nba-card-game
- https://www.invenglobal.com/tag/NBA+RISE
- https://www.gamemeca.com/en/view.php?gid=1782075
- https://www.inews24.com/view/2021080
- https://news.bizwatch.co.kr/article/mobile/2026/07/22/0026
- https://www.thisisgame.com/articles/428056 (403)
- https://www.ungeek.ph/2026/07/nba-rise-closed-beta-test-happening-now-in-the-philippines-and-other-asian-regions/
- https://gamingonphone.com/news/nba-rise-opens-pre-registration-on-mobile-as-the-basketball-card-strategy-game-prepares-for-launch
- https://www.mumuplayer.com/games/nba-rise-basketball-strategy-on-pc.html
- https://pr.nba.com/nba-nbpa-gravity-mobile-gaming-experience-asia-pacific/
- https://dengekionline.com/article/202608/83074
- https://gamebiz.jp/news/430264
- https://gamebiz.jp/news/337867
- https://vegcale.com/?p=4677
- https://news.denfaminicogamer.jp/news/211126f
- https://news.denfaminicogamer.jp/kikakuthetower/211125b
- https://game.watch.impress.co.jp/docs/kikaku/1367576.html
- https://app-liv.jp/5342528/
- https://gravityga.jp/wp-content/uploads/2021/11/press-release_20211101.pdf (via search snippet)
- https://game-i.daa.jp/?cmd=search&word=NBA
- https://search.dcinside.com/post/q/NBA.EB.9D.BC.EC.9D.B4.EC.A6.88

**Competitors**
- https://gaminghq.eu/2026/10/18/nba-live-mobile-shutdown-ea-2026/
- https://gamingpromax.com/ea-nba-live-mobile-shutting-down-october-27/
- https://www.pocketgamer.biz/news/81730/mobile-sports-game-developer-nifty-to-close-after-five-years/
- https://2k.com/en-US/game/nba-supercard
- https://www.pockettactics.com/nba-all-world/shut-down
- https://www.gamemeca.com/en/mv.php?gid=1777675
- https://www.ddaily.co.kr/page/view/2026071016420827430
- https://www.sateconomy.co.kr/news/view/179590249798981
- https://toucharcade.com/games/nba-now-24
- https://gamebiz.jp/news/155885
- https://apps.apple.com/sg/app//id6749753704
- Google Play pages: com.catdaddy.nba2km, com.t2ksports.myteam2k26v2, com.levelinfinite.supernba2021, com.netease.dcd, com.netease.dunkcdjp, com.topps.basketball, com.ea.gp.nbanext, com.koalitygame.hoopland, com.fromthebenchgames.nbamanager15, com.hkqs.nba2026.google, com.denachina.g63002013.android
- App Store ids: 1252850847, 6746614437, 6760640090, 1633590206, 1555216030, 6762259371, 6747395742, 1605197976, 6480451890

**Attempted but blocked or empty:** AppMagic, Sensor Tower, data.ai, AppBrain (403), appfigures (403), justuseapp (404), Reddit (403).
